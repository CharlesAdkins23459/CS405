/// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
/*TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}
*/

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_FALSE(collection->empty());
    ASSET_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    int startSize = collection->size();

    add_entries(5);

    //minimum of 5 entries?
    //if true, is current size less than the previous size = 5?
    ASSERT_TRUE(collection->size() > 4);
    EXPECT_EQ(collection->size() - startSize, 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsMaxSizeGTESizeOfEntries)
{
    //stores max size of collection
    int maxSize = collection->max_size();

    //start with 0 entries
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    //validate max size vs. empty initial collection
    ASSERT_TRUE(maxSize >= collection->size());

    //validate max size for 1 entry
    add_entries(1);
    ASSERT_TRUE(collection->size(), 1);
    ASSERT_TRUE(maxSize >= collection->size());

    //validate max size vs 5 entries
    add_entries(4);
    ASSERT_TRUE(collection->size(), 5);
    ASSERT_TRUE(maxSize >= collection->size());

    //validate max size vs 10 entries
    add_entries(5);
    ASSERT_TRUE(collection->size(), 10);
    ASSERT_TRUE(maxSize >= collection->size());

}



// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsCapacityGTESizeOfEntries)
{
    //validate max size for emtpy collection
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->capacity() >= collection->size());

    //validate max size for 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    ASSERT_TRUE(collection->capacity() >= collection->size());

    //validate max size for 5 entries
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_TRUE(collection->capacity() >= collection->size());


    //validate max size for 10 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_TRUE(collection->capacity() >= collection->size());
}


// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, DidResizeIncreaseVectorSize)
{
    //current size
    int startSize = collection->size();
    //increase start size by 1
    collection->resize(startSize + 1);

    //compare the initial and new size
    ASSERT_TRUE(collection->size() > startSize);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, DidResizeDecreaseVectorSize)
{
    //current size
    int startSize = collection->size();
    //ensure its not 0 because vector cannot decrease to negative size
    if (startSize == 0) {
        add_entries(1);
        startSize = collection->size();
    }
    //deduct 1 from collection
    collection->resize(startSize - 1);
    //validate changes
    ASSERT_TRUE(collection->size() < startSize);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, DidResizeDecreaseVectorSizeToZero)
{
    //current size
    int startSize = collection->size();
    //resize to zero
    collection->resize(startSize - startSize);
    //validate its zero now
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}



// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, CanClearEraseCollection)
{
    //current size
    int startSize = collection->size();
    //ensure collection is not 0 bc it cannot be be negative
    if (startSize == 0) {
        add_entries(1);
    }

    //clear it now
    collection->clear();
    //check its been cleared
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}




// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, CanEraseClearCollection)
{
    //current size
    int startSize = collection->size();
    //validate its not 0, cant be negative in size
    if (startSize == 0) {
        add_entries(1);
    }

    //erase start and ends of collection
    collection->erase(collection->begin(), collection->end());
    //verify its empty and 0
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}




// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, CanReserveAddCapacityButNotSizeOfCollection)
{
    //current size
    int startSize = collection->size();
    int startCapacity = collection->capacity();

    //verify capacity is not max capacity
    ASSERT_FALSE(startCapacity == collection->max_Size());

    //resize erase of start and end of collection
    collection->reserve(startCapacity + 1);
    //validate capacity increased, but size remained unchanged
    EXPECT_EQ(collection->size(), startSize);
    ASSERT_TRUE(collection->capacity() > startCapacity);
}






// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, CanOutOfRangeExceptionThrow)
{
    int startSize = collection->size();

    //validates out of range exception is thrown
    ASSERT_THROW(collection->at(startSize + 1), std::out_of_range);

}





// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
TEST_F(CollectionTest, CanLengthErrorExceptionThrow)
{
    //throws length errors
    ASSERT_THROW(collection->at(startSize + 1), std::length_error);
}

TEST_F(CollectionTest, CanPopBackCollection)
{
    //current size
    int startSize = collection->size();
    //validate start is not 2 and makes it 2
    if (startSize != 2) {
        collection->clear();
        add_entries(2);
    }


    //first element
    int firstElement = collection->at(0);
    //creating 2nd element 
    int secondElement;
    secondElement = firstElement + 1;

    //place secondElement in 2nd position of collection
    collection->at(1) = secondElement;

    collection->pop_back();

    //check 2nd element has been removed, leaving just the first
    ASSERT_EQ(collection->size(), 1);
    ASSERT_TRUE(collection->at(0) < secondElement);



}