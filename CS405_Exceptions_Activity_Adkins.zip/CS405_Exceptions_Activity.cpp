// CS405_Exceptions_Activity.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//creating custom exception
struct CustomException : public std::exception
{
    const char* what() const throw()
    {
        return "Custom Exception";
    }

};

bool do_even_more_custom_application_logic()
{

    std::cout << "Running Even More Custom Application Logic." << std::endl;
    //standard exception
    throw std::exception("Error Test");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    
    catch (std::exception e) {
        std::cout << "An exception occurred." << e.what() << '\n';
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;
    //throws custom exception
    throw (CustomException());

}

float divide(float num, float den)
{
       //checks for 0 in denominator
    if (den == 0)
        throw std::overflow_error("Dividie by zero exception");
    return (num / den);
}

void do_division() noexcept
{
    
    float result = 0;
    float numerator = 10.0f;
    float denominator = 0;

    //tries, catches the divide function and displays the what error
    try { result = divide(numerator, denominator); }
    catch (std::overflow_error e) {
        std::cout << e.what() << "-> ";
    }
        
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
}

int main()
{   //catches all thrown exceptions
    try {

        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic();
    }

    catch (CustomException e) {
        std::cout << "Error code: " << e.what() << '\n';
    }
    //catches standard exception
    catch (std::exception e) {
        std::cout << "Error Code: " << e.what() << '\n';
    }
    //catches all remaining exceptions
    catch (...)
    {
        std::cout << "Exception of unknown type found\n";
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu